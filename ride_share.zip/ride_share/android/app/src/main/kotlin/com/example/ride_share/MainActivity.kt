package com.example.ride_share

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
