class LocationModel {
  double? latitude;
  double? longitude;

  LocationModel({this.latitude, this.longitude});
}
