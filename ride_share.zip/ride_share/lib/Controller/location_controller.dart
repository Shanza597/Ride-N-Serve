import 'package:geolocator/geolocator.dart';
import '../Model/location_model.dart';

class LocationController {
  LocationModel location = LocationModel();

  Future<bool> checkLocationPermission() async {
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return false;
      }
    }
    return true;
  }

  Future<LocationModel?> getCurrentLocation() async {
    bool hasPermission = await checkLocationPermission();
    if (!hasPermission) return null;

    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    location.latitude = position.latitude;
    location.longitude = position.longitude;
    return location;
  }
}
